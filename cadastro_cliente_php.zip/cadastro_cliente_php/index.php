<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastro de Cliente</title>

    <style>

        footer {
            display: flex;
            position: fixed;
            bottom: 0;
            background-color: #f2f2f2;
            height: 50px;
            width: 100%;
            align-items: center;
            font-size: 18px;;
        }

        footer a {
            margin-right: 10px;
        }

    </style>
</head>
<body>

    <h3>Cadastro de Cliente</h3>

    <p>
        Data atual:
        <?php echo date('d/m/Y H:i:s'); ?>
    </p>

    <br>

    <form method="post" action="salvar.php">

        <label>Código: </label>
        <input type="text" name="codigo" maxlength="5">
        <br><br>

        <label>Nome: </label>
        <input type="text" name="nome" maxlength="60">
        <br><br>

        <label>Cidade: </label>
        <input type="text" name="cidade" maxlength="60">
        <br><br>

        <br>

        <button type="submit">Salvar</button>

    </form>

    <footer>
        <a href="index.php">Home</a>
        <a href="listar.php">Listar</a>
    </footer>
    

</body>
</html>