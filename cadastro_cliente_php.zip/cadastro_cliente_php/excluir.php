<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Excluído</title>

    <style>

        footer {
            display: flex;
            position: fixed;
            bottom: 0;
            background-color: #f2f2f2;
            height: 50px;
            width: 100%;
            align-items: center;
            font-size: 18px;;
        }

        footer a {
            margin-right: 10px;
        }

    </style>
</head>
<body>
    
<?php

$codigo = $_POST['codigo'];


// Tratamento de Dados

$codigo = trim($codigo);

$codigo = substr($codigo, 0, 5);

if ($codigo != '') { // Se uma string vazia é transformada em int, seu valor passa a ser 0, o que excluiria registros de código 0 mesmo sem o usuário ter digitado nada
    $codigo = intval($codigo);
}


$caminhoArquivo = './output/cadastro_cliente.csv';

$conteudoArquivo = file_get_contents($caminhoArquivo);

$linhas = explode("\n", $conteudoArquivo);

$novoConteudo = '';

foreach ($linhas as $linha) {

    if ($codigo != '') {

        if (trim($linha) != '') {
            
            $linhaExploded = explode(';', $linha); // Divide a linha num array, tendo o código da linha como índice 0

            if ($codigo != $linhaExploded[0]) { // Se '$codigo' não for igual ao código da linha

                $novoConteudo = $novoConteudo . $linha . "\n";

            }
        }
    }
    
    else { // Se '$codigo' for vazio...
        
        if (trim($linha) != '') { // ...mas a linha não for vazia, não remover o conteúdo do arquivo

            $novoConteudo = $novoConteudo . $linha . "\n";
        
        }
        
    }
}

$arquivo = fopen($caminhoArquivo,"w"); // "w" Limpa o arquivo

fclose($arquivo); // Depois de um 'fopen' é preciso um 'fclose'

file_put_contents($caminhoArquivo, $novoConteudo, FILE_APPEND);

echo "Cliente de código " . $codigo . " excluído.";

?>

    <footer>
        <a href="index.php">Home</a>
        <a href="listar.php">Listar</a>
    </footer>

</body>
</html>

