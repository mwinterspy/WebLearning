<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dados Listados</title>

    <style>

        h1, h2, form {
            text-align: center;
            
        }

        input[type="text"] {
            width: 50px;
        }

        button {
            margin-top: 35px;
            margin-bottom: 70px;
            width: 70px;
            height: 25px;
        }

        table {
            margin-left: auto;
            margin-right: auto;
            margin-top: 15px;
            border-collapse: collapse;
            width: 70%;
        }

        td {
            border: 1px solid #ddd;
            text-align: center;
        }

        tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        footer {
            display: flex;
            position: fixed;
            bottom: 0;
            background-color: #f2f2f2;
            height: 50px;
            width: 100%;
            align-items: center;
            font-size: 18px;;
        }

        footer a {
            margin-right: 10px;
        }

    </style>

</head>
<body>

    <?php

        $caminhoArquivo = './output/cadastro_cliente.csv';

        $conteudoArquivo = file_get_contents($caminhoArquivo);

        $linhas = explode("\n", $conteudoArquivo);  

        $clientes = [];

        foreach ($linhas as $linha) {
            
            // trim -> Desconsidera os espaços em branco no início e no fim da linha
            if (trim($linha) != '') {

                $coluna = explode(";", $linha);

                if (count($coluna) == 3) {

                    $clientes[] = $coluna;

                }
            }
        }

    ?>

    <h1>Tabela de Dados</h1>

    <table>
        <thead>
            <tr id="table_header">
                <td>Código</td>
                <td>Nome</td>
                <td>Cidade</td>
            </tr>
        </thead>

        <tbody>

            <?php foreach ($clientes as $cliente) { ?>

            <tr>
                <td><?php echo $cliente[0] ?></td>
                <td><?php echo $cliente[1] ?></td>
                <td><?php echo $cliente[2] ?></td>
            </tr>

            <?php } ?>

        </tbody>
    </table>

    <br><br>

    <h2>Excluir Registro</h2>

    <form method="post" action="excluir.php">
        <label>Insira o código do registro a ser excluído: </label>
        <input type="text" name="codigo" maxlength="5">
        <br>
        <button type="submit">Excluir</button>
    </form>
    
    <footer>
        <a href="index.php">Home</a>
        <a href="listar.php">Listar</a>
    </footer>

</body>
</html>