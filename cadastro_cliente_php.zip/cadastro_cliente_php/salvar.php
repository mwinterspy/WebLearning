<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Salvo</title>

    <style>

        footer {
            display: flex;
            position: fixed;
            bottom: 0;
            background-color: #f2f2f2;
            height: 50px;
            width: 100%;
            align-items: center;
            font-size: 18px;;
        }

        footer a {
            margin-right: 10px;
        }

    </style>
</head>
<body>
    
<?php

$codigo = $_POST['codigo'];

$nome = $_POST['nome'];

$cidade = $_POST['cidade'];

// Tratamento de dados

$codigo = substr($codigo, 0, 5);
$codigo = intval($codigo);

$nome = substr($nome, 0, 60);

$cidade = substr($cidade, 0, 60);


// Array de dados

$dados = array($codigo, $nome, $cidade);

//print_r($dados);

$linhaDeDados = implode(';', $dados);

//echo $linhaDeDados;

$caminhoArquivo = './output/cadastro_cliente.csv';

file_put_contents($caminhoArquivo, $linhaDeDados . "\n", FILE_APPEND);

echo "Cliente cadastrado com sucesso !";

?>

    <footer>
        <a href="index.php">Home</a>
        <a href="listar.php">Listar</a>
    </footer>

</body>
</html>


